import { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";

interface DownloadProps {
  link?: string;
  filename?: string;
}

export function DownloadAction() {
  const { toast } = useToast();

  useEffect(() => {
    const handleDownload = (event: Event) => {
      const customEvent = event as CustomEvent<DownloadProps>;
      const { link, filename } = customEvent.detail;
      
      if (!link) {
        toast({
          title: "Download Failed",
          description: "No file link was provided for download.",
          variant: "destructive",
        });
        return;
      }
      
      try {
        // Create a temporary link element for downloading
        const downloadLink = document.createElement("a");
        downloadLink.href = link;
        downloadLink.download = filename || link.split("/").pop() || "download";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        toast({
          title: "Download Started",
          description: `Downloading ${filename || "file"}.`,
        });
      } catch (error) {
        console.error("Download error:", error);
        toast({
          title: "Download Failed",
          description: "An error occurred while trying to download the file.",
          variant: "destructive",
        });
      }
    };
    
    window.addEventListener('downloadEvidence', handleDownload as EventListener);
    window.addEventListener('downloadDocument', handleDownload as EventListener);
    
    return () => {
      window.removeEventListener('downloadEvidence', handleDownload as EventListener);
      window.removeEventListener('downloadDocument', handleDownload as EventListener);
    };
  }, [toast]);
  
  // This component doesn't render anything
  return null;
}