import * as React from "react";
import { VariantProps, cva } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

const actionButtonVariants = cva(
  "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        edit: "bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-200",
        status: "bg-amber-50 text-amber-600 hover:bg-amber-100 border border-amber-200",
        delete: "bg-red-50 text-red-600 hover:bg-red-100 border border-red-200",
        more: "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 px-2",
        lg: "h-11 px-8",
        icon: "h-8 w-8",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ActionButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof actionButtonVariants> {
  icon?: LucideIcon;
  label?: string;
  showLabelOnMobile?: boolean;
}

export const ActionButton = React.forwardRef<HTMLButtonElement, ActionButtonProps>(
  ({ className, variant, size, icon: Icon, label, showLabelOnMobile = false, ...props }, ref) => {
    return (
      <Button
        className={cn(actionButtonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      >
        {Icon && <Icon className="h-4 w-4" />}
        {label && (
          <span className={cn("ml-2", !showLabelOnMobile && "hidden md:inline")}>
            {label}
          </span>
        )}
      </Button>
    );
  }
);
ActionButton.displayName = "ActionButton";