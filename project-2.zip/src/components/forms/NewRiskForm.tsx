import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Plus } from "lucide-react";
import { RiskData, RiskDataItem } from "@/types";

// Form schema validation - Only Risk No, Title, and Owner are required
const formSchema = z.object({
  srNo: z.string().optional(), // Now optional as it will be auto-populated
  riskNo: z.string().min(1, "Risk Number is required"),
  title: z.string().min(1, "Title is required"),
  owner: z.string().min(1, "Risk Owner is required"),
  product: z.string().optional(),
  comments: z.string().optional(),
  orgUnits: z.string().optional(),
  jiraTicket: z.string().optional(),
  status: z.string().min(1, "Status is required"),
  summary: z.string().optional(),
  details: z.string().optional(),
  consequences: z.string().optional(),
  justification: z.string().optional(),
  scenarioType: z.string().optional(),
  scenario: z.string().optional(),
  // Risk Levels
  inherentOverall: z.string().optional(),
  inherentAvailability: z.string().optional(),
  inherentConfidentiality: z.string().optional(),
  inherentIntegrity: z.string().optional(),
  residualOverall: z.string().optional(),
  residualAvailability: z.string().optional(),
  residualConfidentiality: z.string().optional(),
  residualIntegrity: z.string().optional(),
  auditComment: z.string().optional(),
});

interface NewRiskFormProps {
  onRiskCreated: (risk: RiskData) => void;
  existingRisks: RiskDataItem[]; // Added to get the count for SR No
}

export function NewRiskForm({ onRiskCreated, existingRisks }: NewRiskFormProps) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("details");
  const [nextSrNo, setNextSrNo] = useState("");
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      srNo: "",
      riskNo: "",
      title: "",
      owner: "",
      product: "",
      comments: "",
      orgUnits: "",
      jiraTicket: "",
      status: "Open",
      summary: "",
      details: "",
      consequences: "",
      justification: "",
      scenarioType: "Acquia Risk Register",
      scenario: "",
      inherentOverall: "Low",
      inherentAvailability: "Low",
      inherentConfidentiality: "Low",
      inherentIntegrity: "Low",
      residualOverall: "Low",
      residualAvailability: "Low",
      residualConfidentiality: "Low",
      residualIntegrity: "Low",
      auditComment: "Initial risk creation",
    },
  });
  
  // Set the next SR No based on existing risks when dialog opens
  useEffect(() => {
    if (open) {
      // Find the highest SR No and increment by 1 to ensure ascending order
      // This handles both numeric and non-numeric SR numbers
      let highestSrNo = 0;
      
      existingRisks.forEach(risk => {
        const srNoAsNumber = parseInt(risk.srNo, 10);
        if (!isNaN(srNoAsNumber) && srNoAsNumber > highestSrNo) {
          highestSrNo = srNoAsNumber;
        }
      });
      
      const newSrNo = (highestSrNo + 1).toString();
      setNextSrNo(newSrNo);
      form.setValue("srNo", newSrNo);
    }
  }, [open, existingRisks, form]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Get the current logged in user if available
    let currentUser = "System";
    try {
      const userData = localStorage.getItem('user');
      if (userData) {
        const user = JSON.parse(userData);
        currentUser = user.name || "System";
      }
    } catch (error) {
      console.error("Error getting user data:", error);
    }
    
    // Create a new risk item with form values
    const newRisk: RiskData = {
      id: `risk-${Date.now()}`, // Generate unique ID
      srNo: nextSrNo,
      riskNo: values.riskNo,
      title: values.title,
      owner: values.owner,
      product: values.product || "",
      comments: values.comments || "",
      orgUnits: values.orgUnits || "",
      jiraTicket: values.jiraTicket || "",
      status: values.status,
      summary: values.summary || "",
      details: values.details || "",
      consequences: values.consequences || "",
      justification: values.justification || "",
      scenarioType: values.scenarioType || "Acquia Risk Register",
      scenario: values.scenario || "",
      inherentRiskLevel: {
        overall: values.inherentOverall as "High" | "Moderate" | "Low" || "Low",
        availability: values.inherentAvailability as "High" | "Moderate" | "Low" || "Low",
        confidentiality: values.inherentConfidentiality as "High" | "Moderate" | "Low" || "Low",
        integrity: values.inherentIntegrity as "High" | "Moderate" | "Low" || "Low",
      },
      residualRiskLevel: {
        overall: values.residualOverall as "High" | "Moderate" | "Low" || "Low",
        availability: values.residualAvailability as "High" | "Moderate" | "Low" || "Low",
        confidentiality: values.residualConfidentiality as "High" | "Moderate" | "Low" || "Low",
        integrity: values.residualIntegrity as "High" | "Moderate" | "Low" || "Low",
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      auditTrail: [
        {
          date: new Date().toISOString(),
          user: currentUser,
          action: "Created",
          details: values.auditComment || "Risk initially created",
        },
      ],
    };

    // Pass the new risk to parent component
    onRiskCreated(newRisk);
    setOpen(false);
    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          <span>New Risk</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Risk</DialogTitle>
          <DialogDescription>
            Enter the details for the new risk item. Fields marked with * are required.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="details">Basic Details</TabsTrigger>
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="risk-levels">Risk Levels</TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="srNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>SR No (Auto-generated)</FormLabel>
                        <FormControl>
                          <Input placeholder="Auto-generated" {...field} disabled />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="riskNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Risk No *</FormLabel>
                        <FormControl>
                          <Input placeholder="RISK-001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Risk Title *</FormLabel>
                      <FormControl>
                        <Input placeholder="Risk title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="owner"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Risk Owner *</FormLabel>
                        <FormControl>
                          <Input placeholder="Risk owner name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="product"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product</FormLabel>
                        <FormControl>
                          <Input placeholder="Product name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="orgUnits"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Org. Units</FormLabel>
                        <FormControl>
                          <Input placeholder="Organizational units" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="jiraTicket"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>JIRA Ticket</FormLabel>
                        <FormControl>
                          <Input placeholder="JIRA-1234" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Open">Open</SelectItem>
                          <SelectItem value="In Progress - Open">In Progress - Open</SelectItem>
                          <SelectItem value="Closed">Closed</SelectItem>
                          <SelectItem value="Remediated">Remediated</SelectItem>
                          <SelectItem value="Mitigated">Mitigated</SelectItem>
                          <SelectItem value="Risk Accepted">Risk Accepted</SelectItem>
                          <SelectItem value="Risk Expired">Risk Expired</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="scenarioType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scenario Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select scenario type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Acquia Risk Register">Acquia Risk Register</SelectItem>
                          <SelectItem value="Widen Risk Register">Widen Risk Register</SelectItem>
                          <SelectItem value="Acquia Optimize-Monsido">Acquia Optimize-Monsido</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="comments"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Comments</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional comments" {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <TabsContent value="description" className="space-y-4">
                <FormField
                  control={form.control}
                  name="summary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Summary</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Brief summary of the risk" {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="details"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Details</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Detailed description of the risk" {...field} rows={4} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="consequences"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Consequences</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Potential consequences" {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="justification"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Justification</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Justification for the risk assessment" {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="scenario"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scenario</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Risk scenario" {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="auditComment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Initial Comment</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Add a comment for this risk creation" 
                          {...field} 
                          rows={2}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <TabsContent value="risk-levels" className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  {/* INHERENT Risk Levels */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">INHERENT Risk Levels</CardTitle>
                      <CardDescription>Risk levels before controls are applied</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="inherentOverall"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>OVERALL</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentAvailability"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>AVAILABILITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentConfidentiality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CONFIDENTIALITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentIntegrity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>INTEGRITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* RESIDUAL Risk Levels */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">RESIDUAL Risk Levels</CardTitle>
                      <CardDescription>Risk levels after controls are applied</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="residualOverall"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>OVERALL</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualAvailability"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>AVAILABILITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualConfidentiality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CONFIDENTIALITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualIntegrity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>INTEGRITY</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Add Risk</Button>
              </DialogFooter>
            </form>
          </Form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}