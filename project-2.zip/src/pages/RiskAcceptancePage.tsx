import { useState, useRef, useEffect, useCallback } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskAcceptanceColumns } from "@/components/tables/risk-acceptance-columns";
import { riskAcceptanceItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, Filter, RefreshCw, Trash2 } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NewRiskAcceptanceForm } from "@/components/forms/NewRiskAcceptanceForm";
import { EditRiskAcceptanceForm } from "@/components/forms/EditRiskAcceptanceForm";
import { ViewRiskAcceptanceDetails } from "@/components/forms/ViewRiskAcceptanceDetails";
import DocumentViewer from "@/components/viewers/DocumentViewer";
import AuditTrailViewer from "@/components/viewers/AuditTrailViewer";
import { UpdateStatusAction } from "@/components/actions/UpdateStatusAction";
import { RiskFilter } from "@/components/filters/RiskFilter";
import { RiskAcceptanceItem, ClosedRiskItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function RiskAcceptancePage() {
  const [data, setData] = useState<RiskAcceptanceItem[]>([]);
  const [filteredData, setFilteredData] = useState<RiskAcceptanceItem[]>([]);
  const [isDeleteAllDialogOpen, setIsDeleteAllDialogOpen] = useState(false);
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState<Record<string, unknown>>({});
  const [currentUser, setCurrentUser] = useState<{username: string, role: string, email?: string} | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Load data from localStorage or use sample data
  useEffect(() => {
    const storedData = localStorage.getItem('riskAcceptanceData');
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      // Sort data by SR No to ensure proper display order
      const sortedData = sortBySrNo(parsedData);
      setData(sortedData);
      setFilteredData(sortedData);
    } else {
      // Initialize with sample data
      const mappedItems = riskAcceptanceItems.map((item, index) => ({
        ...item,
        riskNo: item.number, // Map the number field to riskNo
        srNo: `RA-${(index + 1).toString().padStart(3, '0')}`, // Ensure SR numbers are in sequence
        auditTrail: item.auditTrail || [{
          date: new Date().toISOString(),
          user: "System",
          action: "Created",
          details: "Risk acceptance initially created"
        }]
      }));
      // Sort sample data by SR No
      const sortedSampleData = sortBySrNo(mappedItems);
      setData(sortedSampleData);
      setFilteredData(sortedSampleData);
    }
    setLastUpdated(new Date().toLocaleString());
    
    // Load current user
    const userData = localStorage.getItem('user');
    if (userData) {
      setCurrentUser(JSON.parse(userData));
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('riskAcceptanceData', JSON.stringify(data));
  }, [data]);
  
  // Event listeners for document view, audit trail view, and delete item
  useEffect(() => {
    const handleDocumentView = (event: Event) => {
      const customEvent = event as CustomEvent<{
        link: string;
        title: string;
      }>;
      
      setCurrentDocumentLink(customEvent.detail.link);
      setCurrentDocumentTitle(customEvent.detail.title);
      setIsDocumentViewerOpen(true);
    };
    
    const handleAuditTrailView = (event: Event) => {
      const customEvent = event as CustomEvent<{
        type: string;
        item: RiskAcceptanceItem;
        title: string;
      }>;
      
      if (customEvent.detail.type !== 'risk-acceptance') return;
      
      setAuditTrailItem(customEvent.detail.item);
      setAuditTrailTitle(customEvent.detail.title);
      setIsAuditTrailOpen(true);
    };
    
    const handleDeleteItem = (event: Event) => {
      const customEvent = event as CustomEvent<{
        type: string;
        itemId: string;
        itemTitle: string;
      }>;
      
      if (customEvent.detail.type !== 'risk-acceptance') return;
      
      setItemToDelete({
        id: customEvent.detail.itemId,
        title: customEvent.detail.itemTitle
      });
      setIsDeleteItemDialogOpen(true);
    };
    
    window.addEventListener('viewDocument', handleDocumentView as EventListener);
    window.addEventListener('viewAuditTrail', handleAuditTrailView as EventListener);
    window.addEventListener('deleteItem', handleDeleteItem as EventListener);
    
    return () => {
      window.removeEventListener('viewDocument', handleDocumentView as EventListener);
      window.removeEventListener('viewAuditTrail', handleAuditTrailView as EventListener);
      window.removeEventListener('deleteItem', handleDeleteItem as EventListener);
    };
  }, []);

  // Function to sort data by SR No
  const sortBySrNo = (items: RiskAcceptanceItem[]): RiskAcceptanceItem[] => {
    return [...items].sort((a, b) => {
      // Extract numbers from RA-001, RA-002 format
      const aMatch = a.srNo.match(/RA-(\d+)/);
      const bMatch = b.srNo.match(/RA-(\d+)/);
      
      const aNum = aMatch ? parseInt(aMatch[1], 10) : 0;
      const bNum = bMatch ? parseInt(bMatch[1], 10) : 0;
      
      return aNum - bNum;
    });
  };

  // Function to get the next SR No, always incrementing from the highest existing number
  const getNextSrNo = (): string => {
    let highestSrNo = 0;
    
    // Extract numbers from RA-001, RA-002 format
    data.forEach(item => {
      const match = item.srNo.match(/RA-(\d+)/);
      if (match) {
        const srNoAsNumber = parseInt(match[1], 10);
        if (!isNaN(srNoAsNumber) && srNoAsNumber > highestSrNo) {
          highestSrNo = srNoAsNumber;
        }
      }
    });
    
    return `RA-${(highestSrNo + 1).toString().padStart(3, '0')}`;
  };

  // Function to handle adding a new risk acceptance
  const handleAddRiskAcceptance = (newRiskAcceptance: RiskAcceptanceItem) => {
    // Ensure the new item has the next sequential SR No
    const riskWithSrNo = {
      ...newRiskAcceptance,
      srNo: getNextSrNo(),
      auditTrail: [{
        date: new Date().toISOString(),
        user: currentUser?.username || "System",
        action: "Created",
        details: "Risk acceptance initially created"
      }]
    };
    
    const updatedData = [riskWithSrNo, ...data];
    const sortedData = sortBySrNo(updatedData);
    setData(sortedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Risk Acceptance Added",
      description: "The new risk acceptance has been successfully added.",
    });
  };
  
  // Function to handle updating a risk acceptance
  const handleUpdateRiskAcceptance = useCallback((updatedRiskAcceptance: RiskAcceptanceItem) => {
    // Find the existing item to preserve audit trail
    const existingItem = data.find(item => item.id === updatedRiskAcceptance.id);
    const existingAuditTrail = existingItem?.auditTrail || [];
    
    // Add new audit trail entry
    const newAuditTrail = [
      ...existingAuditTrail,
      {
        date: new Date().toISOString(),
        user: currentUser?.username || "System",
        action: "Updated",
        details: "Risk acceptance details were modified"
      }
    ];
    
    const updatedWithAudit = {
      ...updatedRiskAcceptance,
      auditTrail: newAuditTrail
    };
    
    const updatedData = data.map(item => 
      item.id === updatedWithAudit.id ? updatedWithAudit : item
    );
    
    // Sort the data after update to maintain order
    const sortedData = sortBySrNo(updatedData);
    setData(sortedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Risk Acceptance Updated",
      description: `Risk acceptance item '${updatedRiskAcceptance.title}' has been updated successfully.`,
    });
  }, [data, currentUser, toast]);
  
  // Apply filters to data
  useEffect(() => {
    let result = [...data];
    
    // Apply active filters
    Object.entries(activeFilters).forEach(([key, value]) => {
      if (value === null || value === undefined || value === "") return;
      
      if (typeof value === "string") {
        result = result.filter((item) => {
          // Special case for riskLevel filter
          if (key === "riskLevel" && item.riskLevel) {
            return item.riskLevel.toLowerCase() === value.toLowerCase();
          }
          
          // Special case for riskOwner filter
          if (key === "riskOwner" && item.riskOwner) {
            return item.riskOwner.toLowerCase().includes(value.toLowerCase());
          }
          
          // Special case for orgUnits filter
          if (key === "orgUnits" && item.orgUnits) {
            return item.orgUnits.toLowerCase().includes(value.toLowerCase());
          }
          
          // Special case for department (maps to department)
          if (key === "department" && item.department) {
            return item.department.toLowerCase().includes(value.toLowerCase());
          }
          
          return item[key as keyof RiskAcceptanceItem]?.toString().toLowerCase().includes(value.toLowerCase());
        });
      } else if (typeof value === "boolean") {
        result = result.filter((item) => 
          item[key as keyof RiskAcceptanceItem] === value
        );
      }
    });
    
    setFilteredData(result);
  }, [data, activeFilters]);
  
  // Function to add a risk acceptance item to the closed risks and update risk data items
  const addToClosedRisks = useCallback((riskItem: RiskAcceptanceItem) => {
    // Create a new closed risk item from the risk acceptance item
    const closedRiskItem = {
      id: `cl-${Date.now()}`,
      timestamp: new Date().toISOString(),
      emailAddress: currentUser?.email || "",
      riskNumber: riskItem.riskNo || riskItem.number,
      riskFrNumber: riskItem.raFrNoOrCve,
      riskTitle: riskItem.title,
      riskClosureDate: new Date().toISOString().split('T')[0],
      riskOwner: riskItem.riskOwner,
      riskClosureEvidenceComments: riskItem.comments,
      riskEvidence: riskItem.formReferenceLink,
      reviewedByCiso: false,
      approvalFlag: false, // Start as pending for approval workflow
      status: "Pending",
      approvalDate: new Date().toISOString().split('T')[0],
      rafFiled: riskItem.addedInFair,
      auditTrail: [
        {
          date: new Date().toISOString(),
          user: currentUser?.username || "System",
          action: "Auto-Created",
          details: "Automatically created from Risk Acceptance when status changed to Closed"
        }
      ]
    };
    
    // Get existing closed risk data from localStorage
    const storedData = localStorage.getItem('closedRiskData');
    let closedRiskData = [];
    
    if (storedData) {
      closedRiskData = JSON.parse(storedData);
    }
    
    // Add the new closed risk item to the existing data
    const updatedClosedRiskData = [closedRiskItem, ...closedRiskData];
    localStorage.setItem('closedRiskData', JSON.stringify(updatedClosedRiskData));
    
    // Update all Risk Data items with matching riskNo to "Closed" status
    const riskNo = riskItem.riskNo || riskItem.number;
    if (riskNo) {
      const storedRiskData = localStorage.getItem('riskData');
      
      if (storedRiskData) {
        const riskDataItems = JSON.parse(storedRiskData);
        let updatedAny = false;
        
        const updatedRiskData = riskDataItems.map(item => {
          if (item.riskNo === riskNo) {
            updatedAny = true;
            return {
              ...item,
              status: "Closed",
              auditTrail: [
                ...(item.auditTrail || []),
                {
                  date: new Date().toISOString(),
                  user: currentUser?.username || "System",
                  action: "Status Updated",
                  details: "Automatically closed due to Risk Acceptance status change"
                }
              ],
              updatedAt: new Date().toISOString()
            };
          }
          return item;
        });
        
        if (updatedAny) {
          localStorage.setItem('riskData', JSON.stringify(updatedRiskData));
          toast({
            title: "Related Risks Updated",
            description: `All Risk Data entries with Risk No "${riskNo}" have been updated to "Closed" status.`,
          });
        }
      }
    }
    
    toast({
      title: "Risk Automatically Closed",
      description: `Risk "${riskItem.title}" has been automatically moved to the Closed Risk register as pending approval.`,
    });
  }, [currentUser, toast]);

  // Handle status updates
  useEffect(() => {
    const handleStatusUpdate = (event: Event) => {
      const customEvent = event as CustomEvent<{
        type: string;
        id: string;
        newStatus: string;
      }>;
      
      if (customEvent.detail.type !== 'risk-acceptance') return;
      
      const { id, newStatus } = customEvent.detail;
      const existingItem = data.find(item => item.id === id);
      
      if (existingItem) {
        const updatedItem = {
          ...existingItem,
          status: newStatus as "In place" | "In Progress" | "Expired" | "Closed",
          auditTrail: [
            ...(existingItem.auditTrail || []),
            {
              date: new Date().toISOString(),
              user: currentUser?.username || "System",
              action: "Status Updated",
              details: `Status changed to ${newStatus}`
            }
          ]
        };
        
        handleUpdateRiskAcceptance(updatedItem);
        
        // If status is changed to "Closed", automatically add to Closed Risk section
        if (newStatus === "Closed") {
          addToClosedRisks(existingItem);
        }
      }
    };
    
    window.addEventListener('statusUpdated', handleStatusUpdate as EventListener);
    
    return () => {
      window.removeEventListener('statusUpdated', handleStatusUpdate as EventListener);
    };
  }, [data, currentUser, handleUpdateRiskAcceptance, addToClosedRisks]);
  
  // Handle delete single item
  const handleDeleteItem = () => {
    if (!itemToDelete) return;
    
    const updatedData = data.filter(item => item.id !== itemToDelete.id);
    setData(updatedData);
    localStorage.setItem('riskAcceptanceData', JSON.stringify(updatedData));
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Item Deleted",
      description: `"${itemToDelete.title}" has been successfully deleted.`,
      variant: "destructive",
    });
    
    setIsDeleteItemDialogOpen(false);
    setItemToDelete(null);
  };

  // Handle delete all risks
  const handleDeleteAllRisks = () => {
    setData([]);
    localStorage.setItem('riskAcceptanceData', JSON.stringify([]));
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "All Risk Acceptances Deleted",
      description: "All risk acceptance items have been successfully deleted.",
      variant: "destructive",
    });
    
    // Close the dialog
    setIsDeleteAllDialogOpen(false);
  };
  
  // Handle manual refresh of data
  const handleRefreshData = () => {
    // Re-sort the data to ensure SR numbers are in order
    const sortedData = sortBySrNo([...data]);
    setData(sortedData);
    setLastUpdated(new Date().toLocaleString());
    
    toast({
      title: "Data Refreshed",
      description: "Risk acceptance data has been refreshed and re-sorted.",
    });
  };
  
  // Function to export data as CSV
  const handleExport = () => {
    try {
      // Convert data to CSV format
      const headers = [
        "SR No", "Number", "Title", "RA FR No/CVE", "Risk First Accepted Date", 
        "RA Acceptance Date", "RA End Date", "RA Documentation Status", 
        "Comments", "Form Reference Link", "Department", "Risk Level", 
        "Org Units", "Status", "Summary", "Details", "Risk Owner", 
        "Issue Description", "Blockade", "Added In FAIR"
      ].join(",");
      
      const csvRows = data.map(item => {
        return [
          item.srNo,
          item.number,
          `"${item.title.replace(/"/g, '""')}"`,
          item.raFrNoOrCve,
          item.riskFirstAcceptedDate,
          item.raAcceptanceDate,
          item.raEndDate,
          item.raDocumentationStatus,
          `"${item.comments.replace(/"/g, '""')}"`,
          item.formReferenceLink,
          item.department,
          item.riskLevel,
          `"${item.orgUnits.replace(/"/g, '""')}"`,
          item.status,
          `"${item.summary.replace(/"/g, '""')}"`,
          `"${item.details.replace(/"/g, '""')}"`,
          `"${item.riskOwner.replace(/"/g, '""')}"`,
          `"${item.issueDescription.replace(/"/g, '""')}"`,
          item.blockade ? "Yes" : "No",
          item.addedInFair ? "Yes" : "No"
        ].join(",");
      });
      
      const csvContent = [headers, ...csvRows].join("\n");
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `risk-acceptance-export-${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export Successful",
        description: `${data.length} risk acceptance items have been exported to CSV.`,
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data.",
        variant: "destructive",
      });
    }
  };
  
  // Function to handle import button click
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // State variables for audit trail viewer and delete item dialog
  const [isAuditTrailOpen, setIsAuditTrailOpen] = useState<boolean>(false);
  const [auditTrailItem, setAuditTrailItem] = useState<RiskAcceptanceItem | null>(null);
  const [auditTrailTitle, setAuditTrailTitle] = useState<string>("");
  const [isDeleteItemDialogOpen, setIsDeleteItemDialogOpen] = useState<boolean>(false);
  const [itemToDelete, setItemToDelete] = useState<{id: string, title: string} | null>(null);
  const [currentDocumentLink, setCurrentDocumentLink] = useState<string | null>(null);
  const [currentDocumentTitle, setCurrentDocumentTitle] = useState<string>("");
  const [isDocumentViewerOpen, setIsDocumentViewerOpen] = useState<boolean>(false);
  
  // Function to handle file import
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const rows = content.split('\n');
        
        // Skip header row
        const headers = rows[0].split(',');
        const importedData: RiskAcceptanceItem[] = [];
        
        for (let i = 1; i < rows.length; i++) {
          if (!rows[i].trim()) continue;
          
          // Handle CSV parsing with quoted fields containing commas
          const values: string[] = [];
          let currentValue = '';
          let inQuotes = false;
          
          for (const char of rows[i]) {
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              values.push(currentValue);
              currentValue = '';
            } else {
              currentValue += char;
            }
          }
          values.push(currentValue); // Add the last value
          
          // Map CSV columns to RiskAcceptanceItem properties
          const item: RiskAcceptanceItem = {
            id: `imported-${Date.now()}-${i}`,
            srNo: values[0] || `RA-${(data.length + importedData.length + 1).toString().padStart(3, '0')}`,
            number: values[1] || "",
            title: values[2] || "",
            raFrNoOrCve: values[3] || "",
            riskFirstAcceptedDate: values[4] || "",
            raAcceptanceDate: values[5] || "",
            raEndDate: values[6] || "",
            raDocumentationStatus: values[7] || "",
            comments: values[8] || "",
            formReferenceLink: values[9] || "",
            department: values[10] || "",
            riskLevel: (values[11] === "High" || values[11] === "Moderate" || values[11] === "Low") 
              ? values[11] as "High" | "Moderate" | "Low" 
              : "Low",
            orgUnits: values[12] || "",
            status: (values[13] === "In place" || values[13] === "In Progress" || values[13] === "Expired") 
              ? values[13] as "In place" | "In Progress" | "Expired" 
              : "In Progress",
            summary: values[14] || "",
            details: values[15] || "",
            riskOwner: values[16] || "",
            issueDescription: values[17] || "",
            blockade: values[18]?.toLowerCase() === "yes",
            addedInFair: values[19]?.toLowerCase() === "yes"
          };
          
          importedData.push(item);
        }
        
        if (importedData.length > 0) {
          setData([...importedData, ...data]);
          toast({
            title: "Import Successful",
            description: `${importedData.length} risk acceptance items have been imported.`,
          });
        } else {
          toast({
            title: "Import Notice",
            description: "No valid data found in the imported file.",
          });
        }
      } catch (error) {
        console.error("Import failed:", error);
        toast({
          title: "Import Failed",
          description: "There was an error importing the data. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Count items by status
  const inPlaceCount = data.filter(item => item.status === "In place").length;
  const inProgressCount = data.filter(item => item.status === "In Progress").length;
  const expiredCount = data.filter(item => item.status === "Expired").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Acceptance Register</h2>
          <p className="text-muted-foreground">
            Track and manage accepted risks and their documentation status efficiently for Acquia infrastructure.
          </p>
        </div>
        <div className="flex items-center gap-4">
          {lastUpdated && (
            <span className="text-sm text-muted-foreground">
              Last updated: {lastUpdated}
            </span>
          )}
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => setIsFilterDialogOpen(true)}
            >
              <Filter className="h-4 w-4" />
              <span>Filter</span>
              {Object.keys(activeFilters).length > 0 && (
                <Badge variant="secondary" className="ml-1 bg-blue-100 text-blue-800">
                  {Object.keys(activeFilters).length}
                </Badge>
              )}
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleImportClick}
            >
              <Upload className="h-4 w-4" />
              <span>Import</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleRefreshData}
            >
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
            {/* Delete All Risks Button - Only visible to admin users */}
            {currentUser?.role === "admin" && (
              <Button 
                variant="outline" 
                className="flex items-center gap-2 bg-red-50 hover:bg-red-100 border-red-200"
                onClick={() => setIsDeleteAllDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 text-red-500" />
                <span className="text-red-500">Delete All</span>
              </Button>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileImport}
              accept=".csv"
              className="hidden"
            />
            <NewRiskAcceptanceForm onRiskAcceptanceCreated={handleAddRiskAcceptance} />
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Place
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                {inPlaceCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inPlaceCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                {inProgressCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inProgressCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Expired
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-100 text-lg py-1 px-2">
                {expiredCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((expiredCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Acceptance Data</CardTitle>
          <CardDescription>
            A list of all risks that have been formally accepted for Acquia infrastructure.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskAcceptanceColumns}
          data={filteredData}
          searchPlaceholder="Search accepted risks..."
          pageSize={15}
        />
      </Card>
      
      {/* Include the edit and view components */}
      <EditRiskAcceptanceForm onUpdate={handleUpdateRiskAcceptance} />
      <ViewRiskAcceptanceDetails />
      
      {/* Document Viewer Dialog */}
      <DocumentViewer 
        open={isDocumentViewerOpen}
        onOpenChange={setIsDocumentViewerOpen}
        documentLink={currentDocumentLink}
        title={currentDocumentTitle}
      />
      
      {/* Audit Trail Viewer */}
      <AuditTrailViewer
        open={isAuditTrailOpen}
        onOpenChange={setIsAuditTrailOpen}
        type="risk-acceptance"
        item={auditTrailItem}
        title={auditTrailTitle}
      />
      
      {/* Delete Item Confirmation Dialog */}
      <AlertDialog open={isDeleteItemDialogOpen} onOpenChange={setIsDeleteItemDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600">Delete Risk Acceptance Item?</AlertDialogTitle>
            <AlertDialogDescription>
              <p>You are about to delete the following item:</p>
              <p className="font-bold mt-2">{itemToDelete?.title}</p>
              <p className="mt-2">This action cannot be undone and all associated data will be permanently removed.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteItem}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Item
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <UpdateStatusAction />
      
      {/* Risk Filter Dialog */}
      <RiskFilter 
        open={isFilterDialogOpen}
        onOpenChange={setIsFilterDialogOpen}
        type="risk-acceptance"
        onApplyFilter={(filters) => {
          setActiveFilters(filters);
          toast({
            title: "Filters Applied",
            description: Object.keys(filters).length > 0 
              ? `Applied ${Object.keys(filters).length} filters to risk acceptance data.` 
              : "All filters have been cleared.",
          });
        }}
      />
      
      {/* Delete All Risks Confirmation Dialog - Only for admin users */}
      <AlertDialog open={isDeleteAllDialogOpen} onOpenChange={setIsDeleteAllDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600">⚠️ Warning: Delete All Risk Acceptances?</AlertDialogTitle>
            <AlertDialogDescription>
              <p className="font-bold">This is a destructive operation!</p>
              <p className="mt-2">You are about to delete ALL risk acceptance records in the database. 
              This action cannot be undone and will permanently remove all risk acceptance data.</p>
              <p className="mt-2">Are you absolutely sure you want to proceed?</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteAllRisks}
              className="bg-red-600 hover:bg-red-700"
            >
              Yes, Delete ALL Risk Acceptances
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}