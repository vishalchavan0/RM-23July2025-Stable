export interface RiskEntry {
  id: string;
  title: string;
  description: string;
  severity: "Low" | "Medium" | "High" | "Critical";
  status: "Open" | "In Progress" | "Closed";
  assignedTo: string;
  createdAt: Date;
  updatedAt: Date;
}