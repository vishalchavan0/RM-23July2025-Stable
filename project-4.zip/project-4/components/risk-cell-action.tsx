"use client";

import { useState } from "react";
import { Edit, MoreHorizontal, Trash, CheckCircle, AlertCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/components/ui/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { RiskEntry } from "@/types/risk";

interface CellActionProps {
  data: RiskEntry;
  onEdit: (risk: RiskEntry) => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: string) => void;
}

export const RiskCellAction: React.FC<CellActionProps> = ({
  data,
  onEdit,
  onDelete,
  onUpdateStatus,
}) => {
  const { toast } = useToast();
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const handleDelete = () => {
    onDelete(data.id);
    toast({
      title: "Risk entry deleted",
      description: "The risk entry has been deleted successfully.",
    });
    setIsDeleteModalOpen(false);
  };

  const handleEdit = () => {
    onEdit(data);
  };

  const handleStatusUpdate = (status: string) => {
    onUpdateStatus(data.id, status);
    toast({
      title: "Risk status updated",
      description: `The risk status has been updated to ${status}.`,
    });
  };

  return (
    <>
      <AlertDialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this risk entry
              and remove it from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-8 w-8 p-0">
            <span className="sr-only">Open menu</span>
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Actions</DropdownMenuLabel>
          <DropdownMenuItem onClick={handleEdit}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setIsDeleteModalOpen(true)}>
            <Trash className="mr-2 h-4 w-4" />
            Delete
          </DropdownMenuItem>
          <DropdownMenuLabel>Update Status</DropdownMenuLabel>
          <DropdownMenuItem onClick={() => handleStatusUpdate("Open")}>
            <AlertCircle className="mr-2 h-4 w-4" />
            Open
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleStatusUpdate("In Progress")}>
            <AlertCircle className="mr-2 h-4 w-4" />
            In Progress
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleStatusUpdate("Closed")}>
            <CheckCircle className="mr-2 h-4 w-4" />
            Closed
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
};