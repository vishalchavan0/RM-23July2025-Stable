import { useState, useRef, useEffect, useMemo } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskDataColumns } from "@/components/tables/risk-data-columns";
import { riskDataItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, RefreshCw, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { NewRiskForm } from "@/components/forms/NewRiskForm";
import { EditRiskForm } from "@/components/forms/EditRiskForm";
import { ViewRiskDetails } from "@/components/forms/ViewRiskDetails";
import { FilterBar } from "@/components/filters/FilterBar";
import { RiskData, RiskDataItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const filterConfig = [
  { key: "status", label: "Status", type: "select", options: [
    { value: "Open", label: "Open" },
    { value: "In Progress - Open", label: "In Progress - Open" },
    { value: "Closed", label: "Closed" },
    { value: "Remediated", label: "Remediated" },
    { value: "Mitigated", label: "Mitigated" },
    { value: "Risk Accepted", label: "Risk Accepted" },
    { value: "Risk Expired", label: "Risk Expired" }
  ]},
  { key: "riskOwner", label: "Risk Owner", type: "text" },
  { key: "product", label: "Product", type: "text" },
  { key: "orgUnits", label: "Org. Units", type: "text" },
];

export default function RiskDataPage() {
  const [data, setData] = useState<RiskDataItem[]>([]);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [selectedRisk, setSelectedRisk] = useState<RiskDataItem | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleteAllDialogOpen, setIsDeleteAllDialogOpen] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [currentUser, setCurrentUser] = useState<{username: string, role: string, email?: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const storedData = localStorage.getItem('riskData') || JSON.stringify(riskDataItems);
    setData(JSON.parse(storedData));
    setLastUpdated(new Date().toLocaleString());
    const userData = localStorage.getItem('user');
    if (userData) {
      setCurrentUser(JSON.parse(userData));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('riskData', JSON.stringify(data));
  }, [data]);

  const filteredData = useMemo(() => {
    return data.filter(item => {
      return Object.entries(filters).every(([key, value]) => {
        if (!value) return true;
        const itemValue = item[key as keyof RiskDataItem];
        if (typeof itemValue === 'string') {
          return itemValue.toLowerCase().includes(value.toLowerCase());
        }
        return true;
      });
    });
  }, [data, filters]);

  const handleRowAction = (action: string, row: RiskDataItem) => {
    setSelectedRisk(row);
    if (action === "edit") setIsEditDialogOpen(true);
    else if (action === "view") setIsViewDialogOpen(true);
    else if (action === "delete") setIsDeleteDialogOpen(true);
  };
  
  // Placeholder functions for other actions
  const handleAddRisk = (newRisk: RiskData) => {
    // This function should contain the logic to add a new risk
    console.log("Adding new risk:", newRisk);
  };
  const handleUpdateRisk = (updatedRisk: RiskDataItem) => {
    setData(prevData => prevData.map(risk => risk.id === updatedRisk.id ? updatedRisk : risk));
    toast({ title: "Success", description: "Risk updated successfully." });
  };
  const handleExport = () => console.log("Exporting data...");
  const handleImportClick = () => fileInputRef.current?.click();
  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => console.log("Importing file:", e.target.files?.[0]);
  const handleRefreshData = () => {
      const storedData = localStorage.getItem('riskData') || JSON.stringify(riskDataItems);
      setData(JSON.parse(storedData));
      setLastUpdated(new Date().toLocaleString());
      toast({ title: "Success", description: "Data refreshed." });
  };
  const handleDeleteAllRisks = () => {
      setData([]);
      setIsDeleteAllDialogOpen(false);
      toast({ title: "Success", description: "All risks deleted." });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Register</h2>
          <p className="text-muted-foreground">
            Manage and track all risk items in Acquia infrastructure efficiently.
          </p>
        </div>
        <div className="flex items-center gap-2">
            <NewRiskForm 
              onRiskCreated={handleAddRisk} 
              existingRisks={data}
            />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Register Data</CardTitle>
          <CardDescription>
            A comprehensive list of all identified risks for Acquia infrastructure.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <FilterBar filters={filters} setFilters={setFilters} filterConfig={filterConfig} />
            <DataTable
              columns={riskDataColumns}
              data={filteredData}
              searchPlaceholder="Search risks..."
              onRowAction={handleRowAction}
              pageSize={15}
            />
        </CardContent>
      </Card>
      
      {/* Dialogs */}
      <ViewRiskDetails
        risk={selectedRisk}
        open={isViewDialogOpen}
        onOpenChange={setIsViewDialogOpen}
        onEdit={() => {
          setIsViewDialogOpen(false);
          setIsEditDialogOpen(true);
        }}
        onDelete={() => {
          setIsViewDialogOpen(false);
          setIsDeleteDialogOpen(true);
        }}
      />
      <EditRiskForm
        risk={selectedRisk}
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onRiskUpdated={handleUpdateRisk}
      />
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the risk record.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (selectedRisk) {
                  setData(data.filter(item => item.id !== selectedRisk.id));
                  toast({ title: "Success", description: "Risk deleted." });
                  setIsDeleteDialogOpen(false);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}