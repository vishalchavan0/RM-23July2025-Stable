import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Lock, AlertCircle } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

const formSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
});

export default function LoginPage() {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setError(null);

    // Get users from localStorage
    const storedUsers = localStorage.getItem("users");
    const users = storedUsers ? JSON.parse(storedUsers) : [];

    // Check if any users exist
    if (users.length === 0) {
      // If no users exist in the system yet, create an admin user on first login
      if (values.username.toLowerCase() === "admin") {
        const adminUser = {
          id: "admin-" + Date.now(),
          username: values.username,
          password: values.password, // In a real app, this should be hashed
          name: "Administrator",
          email: "admin@example.com",
          role: "admin",
          createdAt: new Date().toISOString(),
        };
        
        // Save the admin user
        localStorage.setItem("users", JSON.stringify([adminUser]));
        
        // Set current user
        localStorage.setItem("user", JSON.stringify({
          id: adminUser.id,
          username: adminUser.username,
          name: adminUser.name,
          email: adminUser.email,
          role: adminUser.role,
        }));
        
        setIsLoading(false);
        navigate("/");
        return;
      }
    }

    // Find user by username
    const user = users.find((u: any) => 
      u.username.toLowerCase() === values.username.toLowerCase()
    );

    if (!user || user.password !== values.password) {
      setError("Invalid username or password.");
      setIsLoading(false);
      return;
    }

    // Set user in localStorage (without password)
    localStorage.setItem("user", JSON.stringify({
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role,
    }));

    setIsLoading(false);
    navigate("/");
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 py-12 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
            Risk Management Dashboard – Acquia
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Sign in to access the risk management platform
          </p>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="mt-8 bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input {...field} autoComplete="username" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="password" 
                        autoComplete="current-password" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin mr-2">
                      <Lock className="h-4 w-4" />
                    </div>
                    Signing in...
                  </div>
                ) : (
                  <span>Sign in</span>
                )}
              </Button>
            </form>
          </Form>
        </div>

        <div className="mt-4 text-center text-sm text-gray-600">
          <p>For first-time access, login with any credentials to create a new account.</p>
        </div>
      </div>
    </div>
  );
}