import { useState, useRef, useEffect, useMemo } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskAcceptanceColumns } from "@/components/tables/risk-acceptance-columns";
import { riskAcceptanceItems } from "@/data/sampleData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { NewRiskAcceptanceForm } from "@/components/forms/NewRiskAcceptanceForm";
import { EditRiskAcceptanceForm } from "@/components/forms/EditRiskAcceptanceForm";
import { ViewRiskAcceptanceDetails } from "@/components/forms/ViewRiskAcceptanceDetails";
import { FilterBar } from "@/components/filters/FilterBar";
import { RiskAcceptanceItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";

const filterConfig = [
    { key: "status", label: "Status", type: "select", options: [
        { value: "In place", label: "In place" },
        { value: "In Progress", label: "In Progress" },
        { value: "Expired", label: "Expired" }
    ]},
    { key: "riskOwner", label: "Risk Owner", type: "text" },
    { key: "department", label: "Department", type: "text" },
    { key: "riskLevel", label: "Risk Level", type: "select", options: [
        { value: "High", label: "High" },
        { value: "Moderate", label: "Moderate" },
        { value: "Low", label: "Low" }
    ]},
];

export default function RiskAcceptancePage() {
    const [data, setData] = useState<RiskAcceptanceItem[]>([]);
    const [filters, setFilters] = useState<Record<string, string>>({});
    const { toast } = useToast();

    useEffect(() => {
        const storedData = localStorage.getItem('riskAcceptanceData') || JSON.stringify(riskAcceptanceItems);
        setData(JSON.parse(storedData));
    }, []);

    useEffect(() => {
        localStorage.setItem('riskAcceptanceData', JSON.stringify(data));
    }, [data]);
    
    const filteredData = useMemo(() => {
        return data.filter(item => {
            return Object.entries(filters).every(([key, value]) => {
                if (!value) return true;
                const itemValue = item[key as keyof RiskAcceptanceItem];
                if (typeof itemValue === 'string') {
                    return itemValue.toLowerCase().includes(value.toLowerCase());
                }
                return true;
            });
        });
    }, [data, filters]);

    const handleAddRiskAcceptance = (newItem: RiskAcceptanceItem) => {
        setData(prevData => [...prevData, newItem]);
        toast({ title: "Success", description: "Risk acceptance created." });
    };

    const handleUpdateRiskAcceptance = (updatedItem: RiskAcceptanceItem) => {
        setData(prevData => prevData.map(item => item.id === updatedItem.id ? updatedItem : item));
        toast({ title: "Success", description: "Risk acceptance updated." });
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight">Risk Acceptance Register</h2>
                    <p className="text-muted-foreground">
                        Track and manage accepted risks and their documentation status.
                    </p>
                </div>
                <NewRiskAcceptanceForm onRiskAcceptanceCreated={handleAddRiskAcceptance} />
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Risk Acceptance Data</CardTitle>
                    <CardDescription>
                        A list of all formally accepted risks.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <FilterBar filters={filters} setFilters={setFilters} filterConfig={filterConfig} />
                    <DataTable
                        columns={riskAcceptanceColumns}
                        data={filteredData}
                        searchPlaceholder="Search accepted risks..."
                        pageSize={15}
                    />
                </CardContent>
            </Card>

            <EditRiskAcceptanceForm onUpdate={handleUpdateRiskAcceptance} />
            <ViewRiskAcceptanceDetails />
        </div>
    );
}