import { useState, useRef, useEffect, useMemo } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { closedRiskColumns } from "@/components/tables/closed-risk-columns";
import { closedRiskItems } from "@/data/sampleData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { NewClosureForm } from "@/components/forms/NewClosureForm";
import { EditClosureForm } from "@/components/forms/EditClosureForm";
import { FilterBar } from "@/components/filters/FilterBar";
import { ClosedRiskItem } from "@/types";
import { useToast } from "@/components/ui/use-toast";

const filterConfig = [
  { key: "status", label: "Status", type: "select", options: [
      { value: "Closed", label: "Closed" },
      { value: "Pending Approval", label: "Pending Approval" }
  ]},
  { key: "riskOwner", label: "Risk Owner", type: "text" },
  { key: "riskTitle", label: "Risk Title", type: "text" },
];

export default function ClosedRiskPage() {
  const [data, setData] = useState<ClosedRiskItem[]>([]);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const { toast } = useToast();
  
  useEffect(() => {
    const storedData = localStorage.getItem('closedRiskData') || JSON.stringify(closedRiskItems);
    setData(JSON.parse(storedData));
  }, []);

  useEffect(() => {
    localStorage.setItem('closedRiskData', JSON.stringify(data));
  }, [data]);

  const filteredData = useMemo(() => {
    return data.filter(item => {
      return Object.entries(filters).every(([key, value]) => {
        if (!value) return true;
        const itemValue = item[key as keyof ClosedRiskItem];
        if (typeof itemValue === 'string') {
          return itemValue.toLowerCase().includes(value.toLowerCase());
        }
        return true;
      });
    });
  }, [data, filters]);

  const handleAddClosedRisk = (newItem: ClosedRiskItem) => {
    setData(prevData => [...prevData, newItem]);
    toast({ title: "Success", description: "New closure form submitted." });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Closed Risk Register</h2>
          <p className="text-muted-foreground">
            Track and manage closed risks and their documentation status.
          </p>
        </div>
        <NewClosureForm onClosureCreated={handleAddClosedRisk} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Closed Risk Data</CardTitle>
          <CardDescription>
            A list of all risks that have been formally closed.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <FilterBar filters={filters} setFilters={setFilters} filterConfig={filterConfig} />
          <DataTable
            columns={closedRiskColumns}
            data={filteredData}
            searchPlaceholder="Search closed risks..."
            pageSize={15}
          />
        </CardContent>
      </Card>
      
      <EditClosureForm />
    </div>
  );
}