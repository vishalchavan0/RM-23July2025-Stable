import { ColumnDef } from "@tanstack/react-table";
import { RiskDataItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export const riskDataColumns: ColumnDef<RiskDataItem>[] = [
  {
    accessorKey: "srNo",
    header: "SR No",
    cell: ({ row }) => <div className="font-medium">{row.getValue("srNo")}</div>,
  },
  {
    accessorKey: "riskNo",
    header: "Risk No",
    cell: ({ row }) => <div className="font-medium">{row.getValue("riskNo")}</div>,
  },
  {
    accessorKey: "title",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Risk Title
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => <div className="font-medium">{row.getValue("title")}</div>,
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "product",
    header: "Product",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      // ... (badge logic remains the same)
      return <Badge variant="outline">{status}</Badge>;
    },
  },
  {
    accessorKey: "orgUnits",
    header: "Org. Units",
  },
  {
    accessorKey: "inherent",
    header: "INHERENT Risk",
    cell: ({ row }) => {
      const inherent = row.original.inherent;
      const value = inherent?.overall || "N/A";
      // ... (badge logic remains the same)
      return <Badge>{value}</Badge>;
    },
  },
  {
    accessorKey: "residual",
    header: "RESIDUAL Risk",
    cell: ({ row }) => {
      const residual = row.original.residual;
      const value = residual?.overall || "N/A";
      // ... (badge logic remains the same)
      return <Badge>{value}</Badge>;
    },
  },
  // Actions column is now managed by the DataTable component
];