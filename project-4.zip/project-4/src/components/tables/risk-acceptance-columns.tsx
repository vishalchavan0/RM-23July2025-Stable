import { ColumnDef } from "@tanstack/react-table";
import { RiskAcceptanceItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Check, X, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

// Define the actual columns with editable props
export const riskAcceptanceColumns: ColumnDef<RiskAcceptanceItem>[] = [
  {
    accessorKey: "srNo",
    header: "SR No",
  },
  {
    accessorKey: "riskNo",
    header: "Risk No",
  },
  {
    accessorKey: "title",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Risk Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("title")}</div>,
  },
  {
    accessorKey: "raFrNoOrCve",
    header: "RA FR NO/CVE",
  },
  {
    accessorKey: "riskFirstAcceptedDate",
    header: "Risk first Accepted date",
  },
  {
    accessorKey: "raAcceptanceDate",
    header: "RA Acceptance date",
  },
  {
    accessorKey: "raEndDate",
    header: "RA End date",
  },
  {
    accessorKey: "raDocumentationStatus",
    header: "Documentation status",
    cell: ({ row }) => {
      const status = row.getValue("raDocumentationStatus") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Complete"
              ? "bg-green-50 text-green-600 border-green-300"
              : "bg-amber-50 text-amber-600 border-amber-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "comments",
    header: "Comments Form",
  },
  {
    accessorKey: "formReferenceLink",
    header: "Doc Reference link",
    cell: ({ row }) => {
      const link = row.getValue("formReferenceLink") as string;
      
      // Don't use hooks in the render function
      // Instead dispatch an event to open a document in the parent component
      const handleViewDocument = () => {
        if (link) {
          window.dispatchEvent(new CustomEvent('viewDocument', { 
            detail: { 
              link,
              title: row.getValue("title") as string 
            } 
          }));
        }
      };
      
      return (
        <div className="flex items-center">
          {link ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleViewDocument}
                className="h-8 w-8"
                title="View documentation"
              >
                <FileText className="h-4 w-4 text-blue-500" />
              </Button>
              <span className="ml-2 text-xs text-muted-foreground truncate max-w-[100px]">{link}</span>
            </>
          ) : (
            <span className="text-muted-foreground text-xs">No document</span>
          )}
        </div>
      );
    },
  },
  {
    accessorKey: "department",
    header: "Department",
  },
  {
    accessorKey: "riskLevel",
    header: "Risk Level",
    cell: ({ row }) => {
      const level = row.getValue("riskLevel") as string;
      return (
        <Badge
          className={
            level === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : level === "Moderate"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {level}
        </Badge>
      );
    },
  },
  {
    accessorKey: "orgUnits",
    header: "Org. Units",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "In place"
              ? "bg-green-50 text-green-600 border-green-300"
              : status === "In Progress"
                ? "bg-blue-50 text-blue-600 border-blue-300"
                : "bg-red-50 text-red-600 border-red-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "summary",
    header: "Summary",
    cell: ({ row }) => {
      const summary = row.getValue("summary") as string;
      return (
        <div className="max-w-[200px] truncate" title={summary}>
          {summary}
        </div>
      );
    },
  },
  {
    accessorKey: "details",
    header: "Details",
    cell: ({ row }) => {
      const details = row.getValue("details") as string;
      return (
        <div className="max-w-[200px] truncate" title={details}>
          {details}
        </div>
      );
    },
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "addedInFair",
    header: "Added in FAIR",
    cell: ({ row }) => {
      const addedInFair = row.getValue("addedInFair") as boolean;
      return addedInFair ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const risk = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('viewRiskAcceptance', { detail: risk }))}>
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('editRiskAcceptance', { detail: risk }))}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('viewAuditTrail', { 
              detail: {
                type: 'risk-acceptance',
                item: risk,
                title: `Audit Trail: ${risk.title}`
              } 
            }))}>
              View Audit Trail
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.dispatchEvent(new CustomEvent('updateStatus', { 
              detail: {
                type: 'risk-acceptance',
                itemId: risk.id,
                itemTitle: risk.title,
                currentStatus: risk.status
              } 
            }))}>
              Update Status
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => window.dispatchEvent(new CustomEvent('deleteItem', { 
                detail: {
                  type: 'risk-acceptance',
                  itemId: risk.id,
                  itemTitle: risk.title
                } 
              }))}
              className="text-red-600 focus:text-red-600"
            >
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];