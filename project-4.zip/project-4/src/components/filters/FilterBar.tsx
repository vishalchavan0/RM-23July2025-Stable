import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface FilterOption {
  value: string;
  label: string;
}

interface FilterConfig {
  key: string;
  label: string;
  type: "text" | "select";
  options?: FilterOption[];
}

interface FilterBarProps {
  filters: Record<string, string>;
  setFilters: (filters: Record<string, string>) => void;
  filterConfig: FilterConfig[];
}

export function FilterBar({
  filters,
  setFilters,
  filterConfig,
}: FilterBarProps) {
  const handleFilterChange = (key: string, value: string) => {
    setFilters({
      ...filters,
      [key]: value,
    });
  };

  const clearFilters = () => {
    setFilters({});
  };

  const hasActiveFilters = Object.values(filters).some(
    (value) => value && value.length > 0
  );

  return (
    <div className="flex flex-wrap items-center gap-4 rounded-lg border bg-card p-4 shadow-sm">
      {filterConfig.map(({ key, label, type, options }) => (
        <div key={key} className="flex flex-col gap-2">
          <label className="text-sm font-medium text-muted-foreground">
            {label}
          </label>
          {type === "text" ? (
            <Input
              placeholder={`Filter by ${label}...`}
              value={filters[key] || ""}
              onChange={(e) => handleFilterChange(key, e.target.value)}
              className="h-9 w-48"
            />
          ) : (
            <Select
              value={filters[key] || ""}
              onValueChange={(value) => handleFilterChange(key, value)}
            >
              <SelectTrigger className="h-9 w-48">
                <SelectValue placeholder={`All ${label}s`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All</SelectItem>
                {options?.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      ))}
      {hasActiveFilters && (
        <Button
          variant="ghost"
          onClick={clearFilters}
          className="self-end text-sm text-muted-foreground"
        >
          <X className="mr-2 h-4 w-4" />
          Clear All Filters
        </Button>
      )}
    </div>
  );
}