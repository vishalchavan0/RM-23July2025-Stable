import { useState, useEffect } from "react";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";

interface DeleteItemProps {
  type: 'risk' | 'risk-acceptance' | 'closed-risk';
  itemId: string;
  itemTitle: string;
}

export function DeleteConfirmAction() {
  const [open, setOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<DeleteItemProps | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const handleDeleteItem = (event: Event) => {
      const customEvent = event as CustomEvent<DeleteItemProps>;
      setItemToDelete({
        type: customEvent.detail.type,
        itemId: customEvent.detail.itemId,
        itemTitle: customEvent.detail.itemTitle
      });
      setOpen(true);
    };

    window.addEventListener('deleteItem', handleDeleteItem as EventListener);

    return () => {
      window.removeEventListener('deleteItem', handleDeleteItem as EventListener);
    };
  }, []);

  const handleDelete = () => {
    if (!itemToDelete) return;

    // Create a custom event with the item information to be deleted
    window.dispatchEvent(new CustomEvent('itemDeleted', {
      detail: {
        type: itemToDelete.type,
        id: itemToDelete.itemId
      }
    }));

    // Show success toast
    toast({
      title: "Item Deleted",
      description: `"${itemToDelete.itemTitle}" has been deleted.`
    });

    // Close the dialog
    setOpen(false);
    setItemToDelete(null);
  };

  if (!itemToDelete) return null;

  const getTypeLabel = () => {
    switch (itemToDelete.type) {
      case 'risk': return 'Risk';
      case 'risk-acceptance': return 'Risk Acceptance';
      case 'closed-risk': return 'Closed Risk';
      default: return 'Item';
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure you want to delete this {getTypeLabel()}?</AlertDialogTitle>
          <AlertDialogDescription>
            <p>You are about to delete <strong>"{itemToDelete.itemTitle}"</strong>.</p>
            <p className="mt-2">This action cannot be undone. This item will be permanently removed from the system.</p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={handleDelete}
            className="bg-red-600 hover:bg-red-700"
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}