import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ClosedRiskItem } from "@/types";
import { Check, X, File, Download, History, Pencil } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format, parseISO } from "date-fns";

export function RiskDetailsViewer() {
  const [open, setOpen] = useState(false);
  const [risk, setRisk] = useState<ClosedRiskItem | null>(null);

  useEffect(() => {
    const handleViewRiskDetails = (event: Event) => {
      const customEvent = event as CustomEvent<ClosedRiskItem>;
      setRisk(customEvent.detail);
      setOpen(true);
    };

    window.addEventListener('viewClosedRiskDetails', handleViewRiskDetails as EventListener);
    
    return () => {
      window.removeEventListener('viewClosedRiskDetails', handleViewRiskDetails as EventListener);
    };
  }, []);

  if (!risk) return null;

  const formatDate = (dateString: string) => {
    try {
      return format(parseISO(dateString), 'PP');
    } catch (error) {
      return dateString;
    }
  };

  const handleEditRisk = () => {
    // Close the viewer and open the edit form
    setOpen(false);
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('editClosedRiskForm', { detail: risk }));
    }, 100);
  };

  const handleViewEvidence = () => {
    if (!risk.riskEvidence) return;
    
    window.dispatchEvent(new CustomEvent('viewDocument', { 
      detail: { 
        link: risk.riskEvidence,
        title: `Evidence: ${risk.riskTitle}`
      } 
    }));
  };

  const handleViewAuditTrail = () => {
    window.dispatchEvent(new CustomEvent('viewAuditTrail', { 
      detail: {
        type: 'closed-risk',
        item: risk,
        title: `Audit Trail: ${risk.riskTitle}`
      } 
    }));
  };

  const handleDownloadEvidence = () => {
    if (!risk.riskEvidence) return;
    
    window.dispatchEvent(new CustomEvent('downloadEvidence', { 
      detail: { 
        link: risk.riskEvidence,
        filename: `Risk_Evidence_${risk.riskNumber}.pdf` 
      } 
    }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex justify-between items-center">
            <span>Risk Details</span>
            <Badge variant="outline" className={
              risk.status === "Approved" 
                ? "bg-green-50 text-green-600 border-green-300"
                : risk.status === "Rejected"
                  ? "bg-red-50 text-red-600 border-red-300"
                  : "bg-amber-50 text-amber-600 border-amber-300"
            }>
              {risk.status}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Detailed information about the closed risk
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Risk Number</p>
            <p>{risk.riskNumber}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Risk FR Number</p>
            <p>{risk.riskFrNumber}</p>
          </div>
          
          <div className="space-y-1 col-span-2">
            <p className="text-sm font-medium text-muted-foreground">Risk Title</p>
            <p className="font-medium">{risk.riskTitle}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Risk Owner</p>
            <p>{risk.riskOwner}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Risk Closure Date</p>
            <p>{risk.riskClosureDate}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Approval Date</p>
            <p>{risk.approvalDate}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Evidence</p>
            {risk.riskEvidence ? (
              <Button 
                variant="link" 
                className="p-0 h-auto flex items-center text-blue-600 hover:text-blue-800 hover:underline" 
                onClick={handleViewEvidence}
              >
                <File className="h-4 w-4 mr-1" />
                <span className="truncate max-w-[200px]">{risk.riskEvidence}</span>
              </Button>
            ) : (
              <p className="text-muted-foreground text-sm">None</p>
            )}
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Reviewed by CISO</p>
            {risk.reviewedByCiso ? (
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-500 mr-1" />
                <span>Yes</span>
              </div>
            ) : (
              <div className="flex items-center">
                <X className="h-4 w-4 text-red-500 mr-1" />
                <span>No</span>
              </div>
            )}
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Approval Flag</p>
            {risk.approvalFlag ? (
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-500 mr-1" />
                <span>Yes</span>
              </div>
            ) : (
              <div className="flex items-center">
                <X className="h-4 w-4 text-red-500 mr-1" />
                <span>No</span>
              </div>
            )}
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">RAF Filed</p>
            {risk.rafFiled ? (
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-500 mr-1" />
                <span>Yes</span>
              </div>
            ) : (
              <div className="flex items-center">
                <X className="h-4 w-4 text-red-500 mr-1" />
                <span>No</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex gap-2 justify-end border-t pt-4">
          <Button variant="outline" size="sm" className="flex items-center gap-1" onClick={handleViewAuditTrail}>
            <History className="h-4 w-4" />
            Audit Trail
          </Button>
          
          {risk.riskEvidence && (
            <Button variant="outline" size="sm" className="flex items-center gap-1" onClick={handleDownloadEvidence}>
              <Download className="h-4 w-4" />
              Download Evidence
            </Button>
          )}
          
          <Button variant="default" size="sm" className="flex items-center gap-1" onClick={handleEditRisk}>
            <Pencil className="h-4 w-4" />
            Edit Risk
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}