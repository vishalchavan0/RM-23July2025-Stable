import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/components/ui/use-toast";
import { ClosedRiskItem } from "@/types";
import { format } from "date-fns";

export function EditClosureForm() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<ClosedRiskItem | null>(null);
  const [originalData, setOriginalData] = useState<ClosedRiskItem | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const handleEditClosedRiskForm = (event: Event) => {
      const customEvent = event as CustomEvent<ClosedRiskItem>;
      const riskData = customEvent.detail;
      
      setFormData({...riskData});
      setOriginalData({...riskData});
      setOpen(true);
    };

    window.addEventListener('editClosedRiskForm', handleEditClosedRiskForm as EventListener);
    
    return () => {
      window.removeEventListener('editClosedRiskForm', handleEditClosedRiskForm as EventListener);
    };
  }, []);

  const handleChange = (field: keyof ClosedRiskItem, value: string | boolean) => {
    if (formData) {
      setFormData({
        ...formData,
        [field]: value
      });
    }
  };

  const handleSubmit = () => {
    if (!formData) return;

    // Add audit trail entry
    const auditTrail = [
      ...(formData.auditTrail || []),
      {
        date: new Date().toISOString(),
        user: localStorage.getItem('currentUser') || 'System User',
        action: 'Edited',
        details: 'Closed risk details updated'
      }
    ];

    const updatedRisk: ClosedRiskItem = {
      ...formData,
      auditTrail
    };

    // Dispatch custom event with updated risk data
    window.dispatchEvent(new CustomEvent('riskUpdated', {
      detail: {
        type: 'closed-risk',
        item: updatedRisk
      }
    }));

    // Show success notification
    toast({
      title: "Risk Updated",
      description: `Risk "${formData.riskTitle}" has been successfully updated.`,
    });

    // Close the dialog
    setOpen(false);
  };

  if (!formData) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Closed Risk</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="riskNumber">Risk Number</Label>
            <Input
              id="riskNumber"
              value={formData.riskNumber}
              onChange={(e) => handleChange('riskNumber', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="riskFrNumber">Risk FR Number</Label>
            <Input
              id="riskFrNumber"
              value={formData.riskFrNumber}
              onChange={(e) => handleChange('riskFrNumber', e.target.value)}
            />
          </div>

          <div className="space-y-2 col-span-2">
            <Label htmlFor="riskTitle">Risk Title</Label>
            <Input
              id="riskTitle"
              value={formData.riskTitle}
              onChange={(e) => handleChange('riskTitle', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="riskOwner">Risk Owner</Label>
            <Input
              id="riskOwner"
              value={formData.riskOwner}
              onChange={(e) => handleChange('riskOwner', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="riskClosureDate">Risk Closure Date</Label>
            <Input
              id="riskClosureDate"
              value={formData.riskClosureDate}
              onChange={(e) => handleChange('riskClosureDate', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="approvalDate">Approval Date</Label>
            <Input
              id="approvalDate"
              value={formData.approvalDate}
              onChange={(e) => handleChange('approvalDate', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Input
              id="status"
              value={formData.status}
              onChange={(e) => handleChange('status', e.target.value)}
            />
          </div>

          <div className="space-y-2 col-span-2">
            <Label htmlFor="riskEvidence">Risk Evidence (URL/Link)</Label>
            <Input
              id="riskEvidence"
              value={formData.riskEvidence}
              onChange={(e) => handleChange('riskEvidence', e.target.value)}
              placeholder="https://..."
            />
          </div>

          <div className="space-y-4 col-span-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="reviewedByCiso"
                checked={formData.reviewedByCiso}
                onCheckedChange={(checked) => handleChange('reviewedByCiso', !!checked)}
              />
              <Label htmlFor="reviewedByCiso">Reviewed by CISO</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="approvalFlag"
                checked={formData.approvalFlag}
                onCheckedChange={(checked) => handleChange('approvalFlag', !!checked)}
              />
              <Label htmlFor="approvalFlag">Approval Flag</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="rafFiled"
                checked={formData.rafFiled}
                onCheckedChange={(checked) => handleChange('rafFiled', !!checked)}
              />
              <Label htmlFor="rafFiled">RAF Filed</Label>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            Update Risk
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}