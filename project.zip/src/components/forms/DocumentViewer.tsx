import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface DocumentViewerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  documentLink: string | null;
  title: string;
}

interface DocumentDetails {
  link: string;
  title: string;
}

export function DocumentViewer({ 
  open,
  onOpenChange,
  documentLink,
  title
}: DocumentViewerProps) {
  const [document, setDocument] = useState<DocumentDetails | null>(null);

  // Update document state when props change
  useEffect(() => {
    if (documentLink) {
      setDocument({
        link: documentLink,
        title: title
      });
    }
  }, [documentLink, title]);

  // Support for legacy event-based approach
  useEffect(() => {
    const handleViewDocument = (event: Event) => {
      const customEvent = event as CustomEvent<DocumentDetails>;
      setDocument(customEvent.detail);
      onOpenChange(true);
    };

    window.addEventListener('viewDocument', handleViewDocument as EventListener);

    return () => {
      window.removeEventListener('viewDocument', handleViewDocument as EventListener);
    };
  }, [onOpenChange]);

  if (!document && !documentLink) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>{document?.title || title} - Document</DialogTitle>
        </DialogHeader>
        {document?.link.endsWith('.pdf') ? (
          <iframe 
            src={document?.link} 
            width="100%" 
            height="500px"
            title="Document Viewer"
          />
        ) : (
          <div className="p-4 text-center">
            <p>Document link: <a href={document?.link} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{document?.link}</a></p>
            <p className="text-sm text-muted-foreground mt-2">This document cannot be previewed. Click the link above to open it.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}