import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

interface FilterProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApplyFilter: (filters: Record<string, unknown>) => void;
  type: 'risk' | 'risk-acceptance' | 'closed-risk';
}

export function RiskFilter({ open, onOpenChange, onApplyFilter, type }: FilterProps) {
  const [filters, setFilters] = useState<Record<string, unknown>>({});

  const handleFilterChange = (key: string, value: unknown) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleResetFilters = () => {
    setFilters({});
  };

  const handleApplyFilters = () => {
    onApplyFilter(filters);
    onOpenChange(false);
  };

  const getFilterFields = () => {
    switch (type) {
      case 'closed-risk':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="riskNumber">Risk Number</Label>
                <Input
                  id="riskNumber"
                  placeholder="Filter by risk number"
                  value={filters.riskNumber || ""}
                  onChange={(e) => handleFilterChange("riskNumber", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="riskTitle">Risk Title</Label>
                <Input
                  id="riskTitle"
                  placeholder="Filter by risk title"
                  value={filters.riskTitle || ""}
                  onChange={(e) => handleFilterChange("riskTitle", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="riskOwner">Risk Owner</Label>
                <Input
                  id="riskOwner"
                  placeholder="Filter by owner"
                  value={filters.riskOwner || ""}
                  onChange={(e) => handleFilterChange("riskOwner", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={filters.status || ""}
                  onValueChange={(value) => handleFilterChange("status", value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All statuses</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="reviewedByCiso"
                  checked={filters.reviewedByCiso || false}
                  onCheckedChange={(checked) =>
                    handleFilterChange("reviewedByCiso", checked)
                  }
                />
                <Label htmlFor="reviewedByCiso">Reviewed by CISO</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="approvalFlag"
                  checked={filters.approvalFlag || false}
                  onCheckedChange={(checked) =>
                    handleFilterChange("approvalFlag", checked)
                  }
                />
                <Label htmlFor="approvalFlag">Has Approval Flag</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="rafFiled"
                  checked={filters.rafFiled || false}
                  onCheckedChange={(checked) =>
                    handleFilterChange("rafFiled", checked)
                  }
                />
                <Label htmlFor="rafFiled">RAF Filed</Label>
              </div>
            </div>
          </>
        );

      case 'risk-acceptance':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="srNo">SR No</Label>
                <Input
                  id="srNo"
                  placeholder="Filter by SR number"
                  value={filters.srNo || ""}
                  onChange={(e) => handleFilterChange("srNo", e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="riskNo">Risk No</Label>
                <Input
                  id="riskNo"
                  placeholder="Filter by risk number"
                  value={filters.riskNo || ""}
                  onChange={(e) => handleFilterChange("riskNo", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Risk Title</Label>
                <Input
                  id="title"
                  placeholder="Filter by risk title"
                  value={filters.title || ""}
                  onChange={(e) => handleFilterChange("title", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="riskLevel">Risk Level</Label>
                <Select
                  value={filters.riskLevel || ""}
                  onValueChange={(value) => handleFilterChange("riskLevel", value)}
                >
                  <SelectTrigger id="riskLevel">
                    <SelectValue placeholder="All levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All levels</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Moderate">Moderate</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={filters.status || ""}
                  onValueChange={(value) => handleFilterChange("status", value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All statuses</SelectItem>
                    <SelectItem value="In place">In place</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Expired">Expired</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input
                  id="department"
                  placeholder="Filter by department"
                  value={filters.department || ""}
                  onChange={(e) => handleFilterChange("department", e.target.value)}
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="addedInFair"
                  checked={filters.addedInFair || false}
                  onCheckedChange={(checked) =>
                    handleFilterChange("addedInFair", checked)
                  }
                />
                <Label htmlFor="addedInFair">Added in FAIR</Label>
              </div>
            </div>
          </>
        );

      // Default case for 'risk' type
      default:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="riskId">Risk ID</Label>
              <Input
                id="riskId"
                placeholder="Filter by risk ID"
                value={filters.riskId || ""}
                onChange={(e) => handleFilterChange("riskId", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Risk Title</Label>
              <Input
                id="title"
                placeholder="Filter by title"
                value={filters.title || ""}
                onChange={(e) => handleFilterChange("title", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner">Owner</Label>
              <Input
                id="owner"
                placeholder="Filter by owner"
                value={filters.owner || ""}
                onChange={(e) => handleFilterChange("owner", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={filters.status || ""}
                onValueChange={(value) => handleFilterChange("status", value)}
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All statuses</SelectItem>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Filter {type.replace(/-/g, ' ')}s</DialogTitle>
          <DialogDescription>
            Apply filters to narrow down the risk data displayed in the table.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {getFilterFields()}
        </div>

        <DialogFooter className="flex justify-between">
          <Button variant="outline" onClick={handleResetFilters}>
            Reset Filters
          </Button>
          <div className="space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleApplyFilters}>Apply Filters</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}